﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.CalculatorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyAnswerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.QuitPrimeNumberCalculatorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Run = New System.Windows.Forms.Button()
        Me.NumberLimit = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Input1 = New System.Windows.Forms.TextBox()
        Me.Input2 = New System.Windows.Forms.TextBox()
        Me.OutputBox = New System.Windows.Forms.TextBox()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CalculatorToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(382, 28)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'CalculatorToolStripMenuItem
        '
        Me.CalculatorToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CopyAnswerToolStripMenuItem, Me.QuitPrimeNumberCalculatorToolStripMenuItem})
        Me.CalculatorToolStripMenuItem.Name = "CalculatorToolStripMenuItem"
        Me.CalculatorToolStripMenuItem.Size = New System.Drawing.Size(88, 24)
        Me.CalculatorToolStripMenuItem.Text = "Calculator"
        '
        'CopyAnswerToolStripMenuItem
        '
        Me.CopyAnswerToolStripMenuItem.Name = "CopyAnswerToolStripMenuItem"
        Me.CopyAnswerToolStripMenuItem.Size = New System.Drawing.Size(283, 26)
        Me.CopyAnswerToolStripMenuItem.Text = "Copy Answer"
        '
        'QuitPrimeNumberCalculatorToolStripMenuItem
        '
        Me.QuitPrimeNumberCalculatorToolStripMenuItem.Name = "QuitPrimeNumberCalculatorToolStripMenuItem"
        Me.QuitPrimeNumberCalculatorToolStripMenuItem.Size = New System.Drawing.Size(283, 26)
        Me.QuitPrimeNumberCalculatorToolStripMenuItem.Text = "Quit Prime Number Calculator"
        '
        'Run
        '
        Me.Run.Location = New System.Drawing.Point(259, 206)
        Me.Run.Name = "Run"
        Me.Run.Size = New System.Drawing.Size(111, 35)
        Me.Run.TabIndex = 1
        Me.Run.Text = "Calculate"
        Me.Run.UseVisualStyleBackColor = True
        '
        'NumberLimit
        '
        Me.NumberLimit.AutoSize = True
        Me.NumberLimit.Checked = True
        Me.NumberLimit.CheckState = System.Windows.Forms.CheckState.Checked
        Me.NumberLimit.Location = New System.Drawing.Point(12, 214)
        Me.NumberLimit.Name = "NumberLimit"
        Me.NumberLimit.Size = New System.Drawing.Size(161, 21)
        Me.NumberLimit.TabIndex = 2
        Me.NumberLimit.Text = "Enable Number Limit"
        Me.NumberLimit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 47)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 17)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Integer 1:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 93)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(68, 17)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Integer 2:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 154)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(55, 17)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Output:"
        '
        'Input1
        '
        Me.Input1.Location = New System.Drawing.Point(86, 44)
        Me.Input1.MaxLength = 300
        Me.Input1.Name = "Input1"
        Me.Input1.Size = New System.Drawing.Size(275, 22)
        Me.Input1.TabIndex = 6
        '
        'Input2
        '
        Me.Input2.Location = New System.Drawing.Point(86, 90)
        Me.Input2.MaxLength = 300
        Me.Input2.Name = "Input2"
        Me.Input2.Size = New System.Drawing.Size(275, 22)
        Me.Input2.TabIndex = 7
        '
        'OutputBox
        '
        Me.OutputBox.Location = New System.Drawing.Point(73, 151)
        Me.OutputBox.Name = "OutputBox"
        Me.OutputBox.Size = New System.Drawing.Size(288, 22)
        Me.OutputBox.TabIndex = 8
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(382, 253)
        Me.Controls.Add(Me.OutputBox)
        Me.Controls.Add(Me.Input2)
        Me.Controls.Add(Me.Input1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.NumberLimit)
        Me.Controls.Add(Me.Run)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(400, 300)
        Me.MinimumSize = New System.Drawing.Size(400, 300)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Prime Number Calculator"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents CalculatorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CopyAnswerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents QuitPrimeNumberCalculatorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Run As Button
    Friend WithEvents NumberLimit As CheckBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Input1 As TextBox
    Friend WithEvents Input2 As TextBox
    Friend WithEvents OutputBox As TextBox
End Class
