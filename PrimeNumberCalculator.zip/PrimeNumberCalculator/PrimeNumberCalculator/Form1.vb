﻿Public Class Form1
    Private Sub OutputBox_Changed(sender As Object, e As EventArgs) Handles OutputBox.TextChanged
        OutputBox.ForeColor = Color.Black
    End Sub

    Public Sub Calc()
        Try
            Me.OutputBox.Text = ""
            Dim i1 As Integer
            Dim i2 As Integer
            i1 = Convert.ToInt32(Input1.Text)
            i2 = Convert.ToInt32(Input2.Text)
            Dim Output As String
            Output = Convert.ToString(i1 * i2)
            OutputBox.Text = Output
        Catch ex As Exception
            OutputBox.Text = "Error"
            If vbRetry = MsgBox("Unable to calculate.", MsgBoxStyle.AbortRetryIgnore, "Error") Then
                Calc()
            Else
                OutputBox.Text = "Error - " + ex.Message
                OutputBox.ForeColor = Color.Red
            End If
        End Try
    End Sub

    Public Sub Button1_Click(sender As Object, e As EventArgs) Handles Run.Click
        If Input1.TextLength >= 3 Or Input2.TextLength >= 3 Then
            If vbYes = MsgBox("This calculation may take a while. Would you like to proceed?", vbYesNo, "Warning") Then
                Calc()
            End If
        Else
            Calc()
        End If
    End Sub

    Private Sub NumberLimit_CheckedChanged(sender As Object, e As EventArgs) Handles NumberLimit.CheckedChanged
        If NumberLimit.Checked = True Then
            Input1.MaxLength = 300
            Input2.MaxLength = 300
        Else
            Input1.MaxLength = 999999999
            Input2.MaxLength = 999999999
        End If
    End Sub

    Private Sub CopyAnswerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyAnswerToolStripMenuItem.Click
        My.Computer.Clipboard.SetText(OutputBox.Text)
        MsgBox("Copied " + My.Computer.Clipboard.GetText.ToString, MsgBoxStyle.Information, "Copy")
    End Sub

    Private Sub QuitPrimeNumberCalculatorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles QuitPrimeNumberCalculatorToolStripMenuItem.Click
        End
    End Sub

    Private Sub OutputBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles OutputBox.KeyPress
        e.Handled = False
    End Sub
End Class
